	
	<!-- rodape -->
	
	<div class="base-rodape">
		<div class="conteudo">
			<div class="caixa1">
				<h5>CONTATOS</h5>
				<p>Tel: 61 9 9390-9873</p>
				<p>Email: djairn18@gmail.com.br</p>
				<p>Endereço: rua tal Nº 111 bairro tal São Luis MA</p>
			</div>
			
			<div class="caixa2">
				<h5>REDES SOCIAIS</h5>
				<a href="" class="ico face"></a>
				<a href="" class="ico twitter"></a>
				<a href="" class="ico gmais"></a>
				<a href="" class="ico youtube"></a>
				
			</div>
		</div>
		<div class="copy">Copyright - 2015</div>
	</div>
</body>
</html>