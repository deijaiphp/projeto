<div class="limpar"></div>
	
	<div class="conteudo">
		<div class="base-home">
			<h1>últimos posts</h1>
			<div class="base-up">
			<article>	
				<figure>
					<a href="post.html"><img src="upload/img02.jpg">
					<figcaption>Título referente ao post</figcaption></a>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer</p>
										
				</figure>
				<span class="data"><small>Postado em: 20/11/2015</small><a href="post.html#cmt" class="ico-msg"></a></span>
			</article>
			
			<article>	
				<figure>
					<a href="post.html"><img src="upload/img03.jpg">
					<figcaption>Título referente ao post</figcaption></a>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer</p>
										
				</figure>
				<span class="data"><small>Postado em: 20/11/2015</small><a href="post.html#cmt" class="ico-msg"></a></span>
			</article>
			
			<article>	
				<figure>
					<a href="post.html"><img src="upload/img04.jpg">
					<figcaption>Título referente ao post</figcaption></a>
					<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer</p>
										
				</figure>
				<span class="data"><small>Postado em: 20/11/2015</small><a href="post.html#cmt" class="ico-msg"></a></span>
			</article>
			
			</div>
		
			<div class="limpar"></div>
				
			<div class="lado-esq">
				<h1>todos os posts</h1>
			<div class="post-geral">					
					<h2>CATEGORIA <span>PHP</span></h2>
					<article>
						<a href="post.html"><img src="upload/img01.jpg">
						<div class="texto">
							<h3>Título referente ao post</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer</p>			
							<span>Postado em: 20/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					<article>
						<a href="post.html"><img src="upload/img02.jpg">
						<div class="texto">
							<h3>Título referente ao post</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer</p>			
							<span>Postado em: 20/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					<a href="categoria.html" class="btn direito">Ver todos os posts de php</a>
					
				
				</div>
			
				<div class="post-geral">
					<h2>CATEGORIA <span>JAVA</span></h2>
					<article>
						<a href=""><img src="upload/img03.jpg">
						<div class="texto">
							<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh...</p>
							<span>Postado em: 30/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					
					<article>
						<a href="post.html"><img src="upload/img04.jpg">
						<div class="texto">
							<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh...</p>
							<span>Postado em: 30/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					
					<a href="" class="btn direito">Ver todos os posts de java</a>
				</div>
				
				<div class="post-geral">
					<h2>CATEGORIA <span>HTML</span></h2>
					<article>
						<a href="post.html"><img src="upload/img05.jpg">
						<div class="texto">
							<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh...</p>
							<span>Postado em: 30/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					
					<article>
						<a href="post.html"><img src="upload/img06.jpg">
						<div class="texto">
							<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh...</p>
							<span>Postado em: 30/11/2015 <a href="post.html#cmt" class="ico-msg"></a></span>
						</div>
					</article>
					
					<a href="" class="btn direito">Ver todos os posts de html</a>
				</div>
				
			</div>