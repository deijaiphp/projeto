
	
	<!--------------fecha menu esquerdo---------------------->
		
<div class="base-direita">
	<h1>Lista de Usuário</h1>
	<div class="base-lista">
		<div class="cx-lista">		
		<h2>Lista de Usuário</h2>
		<a href="cadastro_usuario.html">Cadastrar Usuário </a>
		<p class="limpar">&nbsp;</p>
						
				<table width="100%" border="0" cellpadding="2" cellspacing="2">
				<tbody>
					<tr>
					  <td width="6%"  align="center" class="tdbc">id</td>
					  <td width="67%"  align="left" class="tdbc">Usuário</td>
					  <td  align="center" colspan="2"  class="tdbc">Ação</td>
					</tr>
					<tr  class="coluna1">
					  <td  align="center">01</td>
					  <td  align="left">Manoel Jailton</td>
					  <td width="14%" align="center"><a href="cadastro_usuario.html">Editar</a></td>
					  <td width="13%" align="center"><a href="cadastro_usuario.html" class="excluir">Excluir</a></td>		
				  </tr>
					<tr  class="coluna2">
					  <td  align="center">02</td>
					  <td  align="left">Jairo sousa</td>
					  <td align="center"><a href="cadastro_usuario.html">Editar</a></td>
					  <td align="center"><a href="cadastro_usuario.html" class="excluir">Excluir</a></td>		
				  </tr>
					<tr  class="coluna1">
					  <td  align="center">03</td>
					  <td  align="left">Talras goes</td>
					  <td align="center"><a href="cadastro_usuario.html">Editar</a></td>
					  <td align="center"><a href="cadastro_usuario.html" class="excluir">Excluir</a></td>		
				  </tr>
					<tr  class="coluna2">
					  <td  align="center">04</td>
					  <td  align="left">Arthur emanuel</td>
					  <td align="center"><a href="cadastro_usuario.html">Editar</a></td>
					  <td align="center"><a href="cadastro_usuario.html" class="excluir">Excluir</a></td>
				  </tr>
				</tbody>
			</table>
	
	</div>
	</div>
</div>

</div>
