<!-- meio -->
<div class="conteudo">
		<!--------------menu esquerdo---------------------->	
	<div class="base-esq">	
	<h1>PAINEL DE CONTROLE</h1>	
		<div class="lado-esq">
				<ul>
					<li><a href="index.php?link=1">Home</a></li>
					<li><a href="index.php?link=2">Categorias</a> </li>				
					<li><a href="index.php?link=4">Posts</a> </li>
					<li><a href="index.php?link=6">Vídeos</a> </li>
					<li><a href="index.php?link=3">Comentários</a> </li>
					<li><a href="index.php?link=5">Usuário</a> </li>
				</ul>
			
		</div>
	</div>
	
	<!--------------fecha menu esquerdo---------------------->