<?php
session_start();
require "../config/config.php";


unset($_SESSION["SITE_CREAMA"]);

header('Location: http://localhost/site_creama/blog/admin/login.php');






 ?>