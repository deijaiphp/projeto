<div class="base-direita">
		<div class="base-home cx-home">
			<img src="imagens/img-home.png">
		</div>
</div>
</div>