<?php

  
   @$id = $_GET["id"];
   @$acao = $_GET["acao"];

   if (isset($acao)) 
   {
    $categoria = consultar("categoria", "categoria_id = $id");
    
    @$txt_categoria = $categoria[0]['categoria_titulo'];
    @$txt_slug = $categoria[0]['categoria_slug'];
   }

 ?>


<div class="base-direita">	
	<h1>CADASTRO DE CATEGORIAS</h1>
		<div class="cx-form">
		<div class="cx-pd">			
			<form action="op_categoria.php" method="post">	
			  <label>
				<strong>Insira uma categoria</strong>
				<input type="text" name="txt_categoria"  value="<?php echo @$txt_categoria ; ?>" size="110">
			  </label>

			  <label>
				<strong>Slug categoria</strong>
				<input type="text" name="txt_slug"  value="<?php echo @$txt_slug ; ?>" size="110">
			  </label>
			  
				<label>
					<div class="cx-but">
						<input type="hidden" name="id" value="<?php echo @$id ; ?>">
						<input type="hidden" name="irpara" value="">							
						<input type="hidden" name="acao" value="<?php echo (@$acao != "") ? @$acao : "Inserir"; ?> ">										
						<input type="submit" name="logar"  value="<?php echo (@$acao != "") ? @$acao : "Inserir"; ?> " class="but">	
					</div>
					</label>
			</form>

		</div>
		</div>
</div>
</div>


	