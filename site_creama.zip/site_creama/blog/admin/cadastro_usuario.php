

<div class="base-direita">	
	<h1>CADASTRO DE usuário</h1>
		<div class="cx-form">
		<div class="cx-pd">			
			<form action="" method="post">	
			  <label>
				<strong>Nome de usuário</strong>
				<input type="text" name="txt_modulo" id="txt_modulo" value="" size="110">
			  </label>
			  
			  <label>
				<strong>Email de usuário</strong>
				<input type="text" name="txt_modulo" id="txt_modulo" value="" size="110">
			  </label>
			  <label class="esq">
				<strong>Senha</strong>
				<input type="text" name="txt_modulo" id="txt_modulo" value="" size="110">
			  </label>
			  
			  <label class="dir">
				<strong>Confirmar Senha</strong>
				<input type="text" name="txt_modulo" id="txt_modulo" value="" size="110">
			  </label>
			  
				<label>
					<div class="cx-but">
						<input type="hidden" name="id" value="">
						<input type="hidden" name="irpara" value="">							
						<input type="hidden" name="acao" value="Inserir">										
						<input type="submit" name="logar" id="logar" value="Inserir" class="but">	
					</div>
					</label>
			</form>

		</div>
		</div>
</div>
</div>


	