<?php
session_start();
require "../config/config.php";
require "../config/crud.php";


$txt_email = $_POST['txt_email'];
$txt_senha = $_POST['txt_senha'];



if (($txt_email != "") && ($txt_senha != "")) 
	{
		$usuario = consultar("usuario", "usuario_email = '$txt_email' and usuario_senha = '$txt_senha'");


    if (isset($usuario))
        {
            
        $_SESSION["SITE_CREAMA"]["USUARIO_ID"] = $usuario[0]['usuario_id'];
		$_SESSION["SITE_CREAMA"]["USUARIO_NOME"] = $usuario[0]['usuario_nome'];
		$_SESSION["SITE_CREAMA"]["USUARIO_EMAIL"] = $usuario[0]['usuario_email'];
		$_SESSION["SITE_CREAMA"]["USUARIO_SENHA"] = $usuario[0]['usuario_senha']; 

		header('Location: http://localhost/site_creama/blog/admin/');

	    }
	 else
	    {

	   
       
        unset($_SESSION["SITE_CREAMA"]);

        header('Location: http://localhost/site_creama/blog/admin/login.php');

		


	    }
		
		
	}





 ?>