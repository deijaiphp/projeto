<?php

require "../config/config.php";
require "../config/crud.php";
require "../config/biblio.php";

$id = $_POST["id"];
$acao = $_POST["acao"];

$botao = $_POST["logar"];

$txt_categoria = $_POST["txt_categoria"];
$slug = slug($txt_categoria);

$dados = array( "categoria_titulo"=> trim($txt_categoria),
            "categoria_slug" => $slug );


	
		if ($acao = "Inserir") 
		{
			inserir("categoria",  $dados);
			header('Location: http://localhost/site_creama/blog/admin/index.php?link=2');
		}

		if ($acao = "Editar") 
		{
			alterar("categoria", $dados, "categoria_id = $id");
			header('Location: http://localhost/site_creama/blog/admin/index.php?link=2');

		}
       if ($acao = "Excluir")
		{
			deletar("categoria", "categoria_id = $id");
			header('Location: http://localhost/site_creama/blog/admin/index.php?link=2');
		}		


 

var_dump($botao);


 ?>