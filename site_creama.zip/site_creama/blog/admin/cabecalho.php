<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Área Administrativa - CREA JR MARANHÃO</title>

<link href="css/reset.css" rel="stylesheet" type="text/css">
<link href="css/estilo.css" rel="stylesheet" type="text/css">

<!--[if lte IE 8]>
<script type="text/javascript">
var htmlshim='abbr,article,aside,audio,canvas,details,figcaption,figure,footer,header,mark,meter,nav,output,progress,section,summary,time,video'.split(',');
var htmlshimtotal=htmlshim.length;
for(var i=0;i<htmlshimtotal;i++) document.createElement(htmlshim[i]);
</script>
<![endif]-->
  <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
 <script type="text/javascript" src="js/abas.js"></script>
</head>


<body>
<!-- topo -->
	<div class="mn-topo">
		<div class="conteudo"><a href="logoff.php" class="but-sair"><span>sair</span></a></div>
	</div>
	<div class="base-topo">
			<div class="conteudo">
			<section>
				<a href="index.php?link=1"><img src="imagens/sua-logo.png"></a>
			<div class="bemvindo">
			<h2>BEM VINDO(A),</h2>
			<h1><?php echo $_SESSION["SITE_CREAMA"]["USUARIO_NOME"]; ?></h1>
			</div>
			</section>
			
			</div>
	</div>
	<div class="limpar"></div>
