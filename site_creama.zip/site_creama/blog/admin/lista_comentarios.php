
	
	<!--------------fecha menu esquerdo---------------------->
		
<div class="base-direita">
	<h1>Lista de comentários</h1>
	<div class="base-lista">
		<div class="cx-lista">
		
		<h2>Lista de comentários</h2>
		<p class="limpar">&nbsp;</p>
	<table width="100%" border="0" cellpadding="2" cellspacing="2">
		<tbody>
			<tr>
			  <td width="5%" align="center" class="tdbc">id</td>
			  <td width="77%" align="center" class="tdbc">Comentarios</td>
			  <td width="18%" align="center" class="tdbc">Ação</td>
			</tr>
	
		  <tr> 						
				
			<td class="coluna1" align="center">01</td>			
			<td class="coluna1">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet...</td>	
			<td align="center" class="coluna1"><a href="#" class="excluir">Excluir</a></td>
			</tr>  <tr> 						
				
			<td class="coluna2" align="center">02</td>			
			<td class="coluna2">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet...</td>	
			<td align="center" class="coluna2"><a href="#" class="excluir">Excluir</a></td>
			</tr>  <tr> 						
				
			<td class="coluna1" align="center">03</td>			
			<td class="coluna1">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet...</td>	
			<td align="center" class="coluna1"><a href="#" class="excluir">Excluir</a></td>
			</tr>	
            </tbody>
            </table>
		
		<div class="cx-paginacao">
			<p></p><div><p>Página 1 de 3</p><br>
			<a href="index.php?link=4&amp;ordem=1&amp;termodabusca=&amp;campo=">Próxima</a> | 
			<a href="index.php?link=4&amp;ordem=23">Última</a></div><p></p>
		</div>

		<p>&nbsp;</p>
		<p>&nbsp;</p>


	</div>
	</div>
</div>

</div>

