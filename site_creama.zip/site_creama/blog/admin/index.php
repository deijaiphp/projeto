
<?php 
session_start();
require "../config/config.php";
require "../config/crud.php";
require "../config/biblio.php";



if ($_SESSION["SITE_CREAMA"]["USUARIO_ID"] == "")
 {
	header('Location: http://localhost/site_creama/blog/admin/login.php');
 }







include "cabecalho.php";	


include "sidebar.php";

@$link = $_GET['link'];


$pag[1] = "home.php";

$pag[2] = "lista_categoria.php";
$pag[3] = "lista_comentarios.php";
$pag[4] = "lista_posts.php";
$pag[5] = "lista_usuario.php";
$pag[6] = "lista_videos.php";

$pag[7] = "cadastro_categoria.php";
$pag[8] = "cadastro_posts.php";
$pag[9] = "cadastro_usuario.php";
$pag[10] = "cadastro_videos.php";

if (!empty($link)) 
{
	if (file_exists($pag[$link])) {

		include $pag[$link];
	}
	else
	{
		include "home.php";
	}
}
else
{
	include "home.php";
}


    

include "rodape.php";






 ?>