
	
	<!--------------fecha menu esquerdo---------------------->
		
<div class="base-direita">
	<h1>Lista de categorias</h1>
	<div class="base-lista">
		<div class="cx-lista">		
		<h2>Lista de categorias</h2>
		<a href="index.php?link=7">Cadastrar categorias </a>
		<p class="limpar">&nbsp;</p>

		<?php
               $sql = "SELECT * FROM categoria";
               $total = total($sql);

              

               if ($total <= 0) 
               {
               	echo "Nenhum resultado para exibir!";
               }
               else
               {


               echo "Existem ".$total. " registros cadastrados!";


		 ?>
						
				<table width="100%" border="0" cellpadding="2" cellspacing="2">
				<tbody>

					<tr>
					  <td width="6%"  align="center" class="tdbc">id</td>
					  <td width="67%"  align="left" class="tdbc">Categoria</td>
					  <td  align="center" colspan="2"  class="tdbc">Ação</td>
					</tr>


                     <?php

                        $categorias = selecionar($sql);

                        $i = 0;

                        foreach ($categorias as $cat) {
                        
                         if($i%2 == 0)
                         {
                         	$col = "coluna2";
                         }
                         else
                         {
                         	$col = "coluna1";
                         }

                      ?>

					<tr  class="<?php echo $col; ?>">
					  <td  align="center"><?php echo  @$cat["categoria_id"]; ?></td>
					  <td  align="left"><?php echo  @$cat["categoria_titulo"]; ?></td>
					  <td width="14%" align="center"><a href="index.php?link=7&acao=Editar&id=<?php echo  @$cat["categoria_id"]; ?>">Editar</a></td>
					  <td width="13%" align="center"><a href="index.php?link=7&acao=Excluir&id=<?php echo  @$cat["categoria_id"]; ?>" class="excluir">Excluir</a></td>		
				  </tr>
				
				<?php $i++; } ?>
				
				</tbody>
			</table>
	
  <?php  } ?>




	</div>
	</div>
</div>

</div>

