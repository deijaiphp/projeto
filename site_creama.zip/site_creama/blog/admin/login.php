
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Login - CREA JR MARANHÃO</title>

<link href="css/reset.css" rel="stylesheet" type="text/css">
<link href="css/estilo.css" rel="stylesheet" type="text/css">

<!--[if lte IE 8]>
<script type="text/javascript">
var htmlshim='abbr,article,aside,audio,canvas,details,figcaption,figure,footer,header,mark,meter,nav,output,progress,section,summary,time,video'.split(',');
var htmlshimtotal=htmlshim.length;
for(var i=0;i<htmlshimtotal;i++) document.createElement(htmlshim[i]);
</script>
<![endif]-->
  <script type="text/javascript" src="js/jquery-1.4.2.min.js"></script>
 <script type="text/javascript" src="js/abas.js"></script>
</head>


<body style="background:#064A5F;">

<div class="base-login">
	<div class="conteudo">
			<div class="cx-login">
				<img src="imagens/img-login.png">
				<form action="logar.php" method="post">
				<label>
					<strong>email</strong>
					<input type="email" name="txt_email" id="" value="">
				 </label>
				 <label>
					<strong>Senha</strong>
					<input type="password" name="txt_senha" id="" value="">
				 </label>
				 <label>
					<input type="submit" name="" id="" value="entrar" class="but">
				 </label>
				</form>
			</div>
	</div>
</div>
</body>
</html>
