<?php include "cabecalho.php"; ?>
	
	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">			
				<h1>categoria php</h1>
				<div class="post-geral">	
					<div class="pesquisa">	
					<article>
						<a href="index.php?link=2"><img src="upload/img02.jpg">
						<div class="texto">
						<h3>Titulo do post aqui</h3></a>
						<span>Postado em: 20/11/2015</span>
						</div>
					</article>	
					
					<article>
						<a href="index.php?link=2"><img src="upload/img02.jpg">
						<div class="texto">
						<h3>Titulo do post aqui</h3></a>
						<span>Postado em: 20/11/2015</span>
						</div>
					</article>
					
					
					<article>
						<a href="index.php?link=2"><img src="upload/img02.jpg">
						<div class="texto">
						<h3>Titulo do post aqui</h3></a>
						<span>Postado em: 20/11/2015</span>
						</div>
						
					</article>
					
					
					<article>
						<a href="index.php?link=2"><img src="upload/img02.jpg">
						<div class="texto">
						<h3>Titulo do post aqui</h3></a>
						<span>Postado em: 20/11/2015</span>
						</div>
						
					</article>
												
				</div>			
				</div>			
			</div>
			
		
		
		<!-- sidebar -->	
		<?php include "sidebar.php"; ?>
	
	<!-- rodape -->	
	<?php include "rodape.php"; ?>