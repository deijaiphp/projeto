<?php include "cabecalho.php"; ?>
	
	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">	
			<div class="postagem">
				<div class="post-geral">
					<div class="postvideo">
						<h2>CATEGORIA <span> PHP</span></h2>
						<div class="video">	
						<iframe width="667" height="370" src="https://www.youtube.com/embed/anTaI2xL8aA" frameborder="0" allowfullscreen></iframe>
						</div>
						<h3>Titulo do post aqui</h3>
						<article> 					
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>								
						</article>
					</div>
				</div>
				<div class="limpar"></div>
				<div class="base-comentario">
					<h1><a name="cmt"></a>COMENTÁRIOS</h1>
						<form action="" method="post" name="comentar" id="comentar">
							<label>
								<span>Nome:</span>
								<input type="text" name="txt_autor" placeholder="Deixe seu nome">
							</label>
							<label>
								<span>Mensagem:</span>
								<textarea placeholder="Deixe aqui seu comentário" rows="5"  name="txt_comentario"></textarea>
							</label>		
							<input type="hidden" name="id" value="<?php echo $id ?>">
							<input type="submit" class="btn" value="Comentar">
						</form>
						<div class="coment">
							<img src="img/usuario.png">
							<div class="texto">
								<span>JOÃO PAULO</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet </p>
							</div>
						</div>
						
						<div class="coment responde">
							<img src="img/usuario.png">
							<div class="texto">
								<span>ANTÔNIO</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet </p>
							</div>
						</div>
						
						<div class="coment">
							<img src="img/usuario.png">
							<div class="texto">
								<span>JOÃO PAULO</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet </p>
							</div>
						</div>
						
						<div class="coment">
							<img src="img/usuario.png">
							<div class="texto">
								<span>JOÃO PAULO</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet </p>
							</div>
						</div>
						
				</div>
				
			</div>
			</div>
			
			
		
		<!-- sidebar -->	
		<?php include "sidebar.php"; ?>
	<!-- rodape -->	
	<?php include "rodape.php"; ?>