<?php include "cabecalho.php"; ?>
	
	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">
				<h1>logar</h1>
				<div class="post-geral formulario">
					<form action="" method="" name="">
						
						<label>
							<span>Email</span>
								<input name="" type="text" placeholder="Digite seu emai">							
						</label>
						<label class="esquerdo">
							<span>Senha</span>
								<input name="" type="text"  placeholder="Digite uma senha">							
						</label>
						<label><input name="" type="submit" value="Entrar" class="btn"></label>
					</form>
				</div>			
			</div>
			
		
		
		<!-- sidebar -->	
		<?php include "sidebar.php"; ?>
	
	<!-- rodape -->	
	<?php include_once "rodape.php"; ?>