<?php
date_default_timezone_set("America/Sao_paulo");
define("SERVIDOR", "localhost");
define("USUARIO", "root");
define("SENHA", "");
define("BANCO", "site_creama");
define("CHARSET", "utf8");



define('URL_BASE','http://localhost/site_crea/blog/');
define('URL_ADMIN','http://localhost/site_crea/blog/admin/');
