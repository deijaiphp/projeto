<?php
	
	function verificaSeMatriculado($id_curso,$id_cliente,$id_formacao){	
		$consulta = consultar("cliente_curso_formacao"," id_curso=$id_curso AND id_cliente = $id_cliente and id_formacao = $id_formacao");
		if ($consulta)
			return true;
		else
			return false;		
	}
	
	function qtde_aulas($id_curso){	
		$consulta = consultar("aulas"," id_curso=$id_curso AND ativo_aula ='S'"," count(id_aula) as qtde");
		if ($consulta)
			return $consulta[0]["qtde"];
		else
			return 0;		
	}
	
	function indice_aulas_assistida($id_curso,$id_cliente){	
		$lstAula = consultar("aulas_assistidas"," id_curso=$id_curso and id_cliente = $id_cliente order by id_aula");
		if($lstAula){
			foreach($lstAula as $aula){						
				$matriz[] = $aula["id_aula"];
			}			
		}else
			$matriz = false;
			
		return $matriz;		
	}
	
	function lista_aulas_assistida($id_curso,$id_cliente){	
		$lstAula = consultar("aulas_assistidas"," id_curso=$id_curso and id_cliente = $id_cliente order by id_aula");
		if($lstAula){		
			foreach($lstAula as $aula){		
				$matriz[$aula["id_aula"]] = $aula;
			}			
		}else
			$matriz = false;
			
		return $matriz;		
	}	
	
									
	function indice_exercicios_resolvidos($id_curso=null,$id_cliente, $id_modulo=null){
		if($id_modulo)
			$lstExercicio = consultar("	modulo_curso, curso, modulo, exercicios_resolvidos", "modulo_curso.id_curso = curso.id_curso and 
										modulo_curso.id_modulo = modulo.id_modulo and modulo_curso.id_curso = exercicios_resolvidos.id_curso and
										modulo_curso.id_modulo = $id_modulo and exercicios_resolvidos.id_cliente = $id_cliente ");
		else
			$lstExercicio = consultar("exercicios_resolvidos"," id_curso=$id_curso and id_cliente = $id_cliente order by id_exercicio_resolvido");
			
		if($lstExercicio){
			foreach($lstExercicio as $exercicio){						
				$matriz[] = $exercicio["id_exercicio"];
			}			
		}else
			$matriz = false;
		return $matriz;		
	}
	
	function lista_exercicios_resolvidos($id_curso=null,$id_cliente, $id_modulo=null){	
		if($id_modulo)
			$lstExercicio = consultar("	modulo_curso, curso, modulo, exercicios_resolvidos", "modulo_curso.id_curso = curso.id_curso and 
										modulo_curso.id_modulo = modulo.id_modulo and modulo_curso.id_curso = exercicios_resolvidos.id_curso and
										modulo_curso.id_modulo = $id_modulo and exercicios_resolvidos.id_cliente = $id_cliente ");
		else
			$lstExercicio = consultar("exercicios_resolvidos"," id_curso=$id_curso and id_cliente = $id_cliente order by id_exercicio_resolvido");
			
		if($lstExercicio){
			foreach($lstExercicio as $exercicio){		
				$matriz[$exercicio["id_exercicio"]] = $exercicio;
			}			
		}else
			$matriz = false;
			
		return $matriz;		
	}
	
	function qtde_exercicios($id_curso){	
		$consulta = consultar("exercicios"," id_curso=$id_curso "," count(id_exercicio) as qtde");
		if ($consulta)
			return $consulta[0]["qtde"];
		else
			return 0;		
	}
	
	function indice_cursos_inscritos($id_cliente){	
		$lstCurso = consultar("cliente_curso"," id_cliente = $id_cliente order by id_curso");
		if($lstCurso){
			foreach($lstCurso as $curso){						
				$matriz[] = $curso["id_curso"];
			}			
		}else
			$matriz = false;	
		return $matriz;		
	}
	
	function lista_cursos_inscritos($id_cliente){	
		$lstCurso = consultar("cliente_curso","  id_cliente = $id_cliente order by id_curso");
		if($lstCurso){
			foreach($lstCurso as $curso){		
				$matriz[$curso["id_curso"]] = $curso;
			}			
		}else
			$matriz = false;	
		return $matriz;		
	}
	
	function progresso($id_cliente, $id_curso=null){
		if($id_curso!=null){
            $curso              =  consultar("curso", "id_curso = $id_curso");
            $qtde_total         =  consultar("aulas","id_curso = '$id_curso' ", "count(*) as qtde");
            $qtde_assistidas    =  consultar("aulas_assistidas","id_cliente = '$id_cliente' and id_curso = '$id_curso' ", "count(*) as qtde");
            $historico  = array("id_curso" => $curso[0]["id_curso"],"imagem" => $curso[0]["imagem"],"curso"=> $curso[0]["curso"], "total" => $qtde_total[0], "assistida"=>$qtde_assistidas[0] );
        }else{
        
            $meus_cursos = consultar("cliente_curso, curso, cliente ", " curso.id_curso = cliente_curso.id_curso and cliente.id_cliente = cliente_curso.id_cliente and cliente_curso.id_cliente = $id_cliente");
            
            if(!empty($meus_cursos)){

                foreach ($meus_cursos as $curso){
					$id_curso = $curso["id_curso"];
					$qtde_total         =  consultar("aulas","id_curso = '$id_curso' ", "count(*) as qtde");
					$qtde_assistidas    =  consultar("aulas_assistidas","id_cliente = '$id_cliente' and id_curso = '$id_curso' ", "count(*) as qtde");

                    $historico[]  =  array("id_curso" => $curso["id_curso"],
											"imagem" => $curso["imagem"],
                                            "curso"=> $curso["curso"], 
											"total" => $qtde_total[0]["qtde"],
                                            "assistida"=>$qtde_assistidas[0]["qtde"], 
											"gratis"=>$curso["gratis"] );

                }
            }else{
                $historico=null;
            }
        }          
       
       return $historico;
	
	}
	 function passar_video($id_aula,$id_curso){	
                 
            $todas_aulas = consultar("aulas"," id_curso = $id_curso AND ativo_aula ='S' ");
            $tamanho =  count($todas_aulas);
            $data = date("Y-m-d");
            $hora = date("H:i:s");   
            
                for($i=0;$i<$tamanho;$i++){

                    if($todas_aulas[$i]["id_aula"]==$id_aula){
                        $atual = $todas_aulas[$i]["id_aula"];
                        if($i==0)
                            $anterior = "";
                        else
                            $anterior[] = array("id" =>$todas_aulas[$i-1]["id_aula"], "slug" => $todas_aulas[$i-1]["slug_aula"]);

                        if($i==$tamanho-1)
                            $proxima = "";
                        else
                            $proxima[] = array("id" =>$todas_aulas[$i+1]["id_aula"],"slug" =>$todas_aulas[$i+1]["slug_aula"]);                        
                      
                    }                
                }
                $dados_video = array($anterior, $proxima);
           
            
            return $dados_video;
        }
	 function passar_exercicio($id_exercicio,$id_curso,$id_modulo=null){	
            if($id_modulo)     
				$todos_exercicios = $lstExercicio = consultar("	modulo_curso, curso, exercicios", "modulo_curso.id_curso = curso.id_curso and 
										 modulo_curso.id_curso = exercicios.id_curso and modulo_curso.id_modulo = $id_modulo  ");
			else
				$todos_exercicios = consultar("exercicios"," id_curso = $id_curso ");
            $tamanho =  count($todos_exercicios);
            $data = date("Y-m-d");
            $hora = date("H:i:s");   
            
                for($i=0;$i<$tamanho;$i++){

                    if($todos_exercicios[$i]["id_exercicio"]==$id_exercicio){
                        $atual = $todos_exercicios[$i]["id_exercicio"];
                        if($i==0)
                            $anterior = "";
                        else{
                            if($id_modulo)  
								$anterior[] = array("id" =>$todos_exercicios[$i-1]["id_exercicio"],"id_curso" =>$todos_exercicios[$i-1]["id_curso"] ,"id_modulo" =>$todos_exercicios[$i-1]["id_modulo"] );
							else	
								$anterior[] = array("id" =>$todos_exercicios[$i-1]["id_exercicio"] );
						}
						
                        if($i==$tamanho-1)
                            $proxima = "";
                        else{
							if($id_modulo)  
								$proxima[] = array("id" =>$todos_exercicios[$i+1]["id_exercicio"],"id_curso" =>$todos_exercicios[$i+1]["id_curso"] ,"id_modulo" =>$todos_exercicios[$i+1]["id_modulo"]); 
							else
								$proxima[] = array("id" =>$todos_exercicios[$i+1]["id_exercicio"]); 
					   }
                      
                    }                
                }
                $dados_exercicio = array($anterior, $proxima);
           
            
            return $dados_exercicio;
        }
		
		function passar_video_linha_tempo($id_video, $id_cliente){
                 
            $todos_videos = consultar(" video_linha_tempo vlt, linha_tempo_cliente ltc",
									 " vlt.id_video_linha_tempo = ltc.id_video_linha_tempo AND ltc.id_cliente = $id_cliente  ");
			//var_dump($todos_videos);						 
            $tamanho =  count($todos_videos);
            $data = date("Y-m-d");
            $hora = date("H:i:s");  
			
            for($i=0;$i<$tamanho;$i++){

                    if($todos_videos[$i]["id_video_linha_tempo"]==$id_video){
                        $atual = $todos_videos[$i]["id_video_linha_tempo"];
                        if($i==0)
                            $anterior = "";
                        else
                            $anterior[] = array("id" =>$todos_videos[$i-1]["id_video_linha_tempo"], "slug" => $todos_videos[$i-1]["slug_video_linha_tempo"]);

                        if($i==$tamanho-1)
                            $proxima = "";
                        else
                            $proxima[] = array("id" =>$todos_videos[$i+1]["id_video_linha_tempo"],"slug" =>$todos_videos[$i+1]["slug_video_linha_tempo"]);                        
                      
                    }                
                }
                $dados_video = array($anterior, $proxima);
           
            
            return $dados_video;
        }
	
		function passar_video_venda($id_aula,$id_formacao){	
                 
            $todas_aulas = consultar("videos_venda_formacao"," id_formacao = $id_formacao AND ativo ='S' ");
            $tamanho =  count($todas_aulas);
            $data = date("Y-m-d");
            $hora = date("H:i:s");   
            
                for($i=0;$i<$tamanho;$i++){

                    if($todas_aulas[$i]["id_videos_venda_formacao"]==$id_aula){
                        $atual = $todas_aulas[$i]["id_videos_venda_formacao"];
                        if($i==0)
                            $anterior = "";
                        else
                            $anterior = $todas_aulas[$i-1]["id_videos_venda_formacao"];

                        if($i==$tamanho-1)
                            $proxima = "";
                        else
                            $proxima = $todas_aulas[$i+1]["id_videos_venda_formacao"];                        
                      
                    }                
                }
                $dados_video = array($anterior, $proxima);
           
            
            return $dados_video;
        }
		
		function novoCliente($nome,$email,$senha,$id_afiliado,$origem){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 
			if ($senha==null)
				$senha = "mudar123";
            $inseriu=inserir("cliente", array(
									"id_afiliado" 		=>  $id_afiliado,
									"cliente" 			=>	$nome, 
									"email" 			=>	$email, 
									"senha" 			=>	$senha, 
									"data_cadastro" 	=>	$data, 
									"data_ultimo_acesso" =>	$data, 
									"hora_ultimo_acesso" =>	$hora, 
									"origem" 			=>	$origem 
									)
					);
					
			if ($inseriu){ 
				$cliente = consultar("cliente", "email = '$email' ");
				if($cliente){
					foreach($cliente as $cli);
					$_SESSION['CLIENTE'] 	= $cli;
					$id_cliente 	= $cli["id_cliente"];
					$ativou_linha 	= $cli["liberou_linha_tempo"];
					if($ativou_linha!='S')
						primeiraLinhaTempo($id_cliente);
				}
				return true;
			}else
				return false;
        
	}	
	
	function adicionarLinhaTempo($id_cliente, $id_chamada, $id_linha){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 
			
			$linha = consultar("linha_tempo_cliente", "id_cliente=$id_cliente and id_chamada_linha_tempo= $id_chamada");
			
			if(!$linha){
				inserir("linha_tempo_cliente", array(	"id_linha_tempo" =>$id_linha,
													"id_chamada_linha_tempo" =>$id_chamada,
													"id_cliente" =>$id_cliente,
													"data_envio" => $data,
													"ativo" =>"S",
													"abriu" =>"N",
													"destaque" =>"N"));
			}
								
	}
	
		function primeiraLinhaTempo($id_cliente){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 
													
			inserir("linha_tempo_cliente", array(	"id_linha_tempo" =>1,
													"id_chamada_linha_tempo" =>4,
													"id_cliente" =>$id_cliente,
													"data_envio" => $data,
													"ativo" =>"S",
													"abriu" =>"N",
													"destaque" =>"N"));
													
			inserir("linha_tempo_cliente", array(	"id_linha_tempo" =>1,
													"id_chamada_linha_tempo" =>3,
													"id_cliente" =>$id_cliente,
													"data_envio" =>$data,
													"ativo" =>"S",
													"abriu" =>"N",
													"destaque" =>"N"));
													
			inserir("linha_tempo_cliente", array(	"id_linha_tempo" =>1,
													"id_chamada_linha_tempo" =>1,
													"id_cliente" =>$id_cliente,
													"data_envio" =>$data,
													"ativo" =>"S",
													"abriu" =>"N",
													"destaque" =>"N"));
			inserir("linha_tempo_cliente", array(	"id_linha_tempo" =>1,
													"id_chamada_linha_tempo" =>34,
													"id_cliente" =>$id_cliente,
													"data_envio" => $data,
													"ativo" =>"S",
													"abriu" =>"N",
													"destaque" =>"N"));
													
			$alterou = alterar("cliente", array("liberou_linha_tempo" => "S"), " id_cliente = $id_cliente");					
	}
	
	function adicionarPerfil($id_cliente, $id_perfil){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 			
			
			$perfil = consultar("perfil_cliente", " id_cliente = '$id_cliente' and id_perfil = '$id_perfil' ");
			if(!$perfil){
				inserir("perfil_cliente", array("id_cliente" =>$id_cliente,
												"id_perfil"  =>$id_perfil,
												"data_perfil" => $data));	
			}
	}
	
	function adicionarCurso($id_cliente, $id_curso){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 			
			$consulta = consultar("cliente_curso"," id_cliente = $id_cliente AND id_curso=$id_curso ");
			if(!$consulta){
				$dados = array(
						   "id_curso" => $id_curso,
						   "status" => "Cursando",
						   "data_matricula" => $data,
						   "hora_matricula" => $hora,
						   "id_cliente"=> $id_cliente
					   );
				$inserir = inserir("cliente_curso",$dados);
			}
	}
	
	function comprarFormacao($id_cliente, $id_formacao,$id_afiliado,$origem){	
            @$data			= date("Y-m-d");		
			@$hora			= date("H:i:s"); 			
			
			
				$dados = array(
						   "id_formacao" 	=> $id_formacao,
						   "id_cliente"		=> $id_cliente,
						   "pago" 			=> "N",
						   "data_compra" 	=> $data,
						   "hora_compra" 	=> $hora,
						   "id_afiliado" 	=> $id_afiliado,
						   "origem" 		=> $origem
					   );
				$inserir = inserir("venda_formacao",$dados);
			
	}
	
	function nivel_atual($id_cliente, $id_formacao){	
		$consulta = consultar(" historico_niveis "," id_cliente =$id_cliente and id_formacao = $id_formacao order by id_nivel desc LIMIT 1 ");
		if($consulta){
		   return $consulta; 
		}else{
			return false;
		}			
	}
	
	function inserir_historico_nivel($id_cliente, $id_formacao,$id_nivel=null){	
		$nivel = nivel_atual($id_cliente, $id_formacao);
		if (!$nivel){
            $id_nivel = primeiro_nivel_formacao($id_formacao); 
         }else{
             $id_nivel=$id_nivel;
         }

		$data = date("Y-m-d");
         
         $dados=array(
                 "id_formacao" => $id_formacao,
                 "id_cliente"  => $id_cliente,
                 "id_nivel"    =>$id_nivel ,
                 "inicio_nivel" => $data
             ); 
			 
		if($id_nivel!=null){
             if(!verifica_cadastro_historico_nivel($id_cliente, $id_formacao, $id_nivel)){
                 inserir("historico_niveis",$dados);
             }
         }
	}
	
	
	function primeiro_nivel_formacao($id_formacao){
		$consulta = consultar(" nivel "," id_formacao = $id_formacao order by id_nivel asc LIMIT 1 ");

		return $consulta[0]["id_nivel"];
        
     }
	 
	function verifica_cadastro_historico_nivel($id_cliente, $id_formacao, $id_nivel=null){         
         $consulta=consultar("historico_niveis","id_formacao = $id_formacao and id_cliente =$id_cliente and id_nivel = $id_nivel ");
         
         if($consulta){
            return true;
         }else{
             return false;
         }
        
     }
	function modulo_atual($id_cliente, $id_formacao){	
		$consulta = consultar(" historico_modulos "," id_cliente =$id_cliente and id_formacao = $id_formacao order by id_modulo desc LIMIT 1 ");
		if($consulta){
		   return $consulta; 
		}else{
			return false;
		}			
	}
	
	function inserir_historico_modulo($id_cliente, $id_formacao, $id_modulo=null,$id_nivel=null){	
		$modulo = modulo_atual($id_cliente, $id_formacao);
		$primeiro_modulo = primeiro_modulo_formacao($id_formacao); 
		if (!$modulo){
            $id_modulo 	= $primeiro_modulo["id_modulo"]; 
            $id_nivel 	= $primeiro_modulo["id_nivel"]; 
         }else{
             $id_modulo= $id_modulo;
             $id_nivel=$id_nivel;
         }

		$data = date("Y-m-d");
         
        $dados=array(
                 "id_formacao" 		=> $id_formacao,
                 "id_cliente"  		=> $id_cliente,
                 "id_nivel"    		=>$id_nivel ,
                 "id_modulo"    	=>$id_modulo ,
                 "status"    		=>"Cursando" ,
                 "enviada_solicitacao"    	=>"N" ,
                 "inicio_modulo" => $data
             );
			 
		if($id_modulo!=null){
             if(!verifica_cadastro_historico_modulo($id_cliente, $id_formacao, $id_modulo)){
                 inserir("historico_modulos",$dados);
             }
         }
	}
	
	 function primeiro_modulo_formacao($id_formacao){
		$consulta = consultar(" modulo "," id_formacao = $id_formacao order by id_modulo asc LIMIT 1 ");

		return $consulta[0];
        
     }
	
    function verifica_cadastro_historico_modulo($id_cliente, $id_formacao, $id_modulo=null){         
         $consulta=consultar("historico_modulos","id_formacao = $id_formacao and id_cliente =$id_cliente and id_modulo = $id_modulo ");
         
         if($consulta){
            return true;
         }else{
             return false;
         }
        
     }

	function faz_primeira_matricula($id_formacao, $id_cliente){
			$modulo =primeiro_modulo_formacao($id_formacao);
			
			//Matricular nos cursos do pr�ximo m�dulo
			matricular_no_modulo($id_formacao, $id_cliente,$modulo["id_modulo"]);
	}     

	function matricular_no_modulo($id_formacao, $id_cliente, $id_modulo){
		$todos_os_cursos = consultar("modulo_curso","id_modulo =$id_modulo");
		
		foreach($todos_os_cursos as $curso){
			matricular($id_formacao,$curso["id_curso"],$id_cliente,$curso["id_modulo"],$curso["id_nivel"]);			
		}
	}
	
	function matricular($id_formacao,$id_curso,$id_cliente,$id_modulo,$id_nivel){            
            $data = date("Y-m-d");
            $hora = date("H:m:s");
            $dados = array(
               "id_curso" 		=> $id_curso,
               "status" 		=> "Cursando",
               "data_matricula" => $data,
               "hora_matricula" => $hora,
               "id_cliente"		=> $id_cliente,
               "id_formacao" 	=> $id_formacao,
               "id_nivel" 		=> $id_nivel,
               "id_modulo" 		=> $id_modulo
           );
           
		   //var_dump($dados);
            $consulta = consultar("cliente_curso_formacao", " id_cliente= $id_cliente and id_formacao=$id_formacao and id_curso =$id_curso ");
			//var_dump($consulta);
           if(!$consulta){
               inserir("cliente_curso_formacao",$dados);
               return true;
           }else{
               return false;
           }
        }
	
	function concluir_modulo($id_modulo, $id_cliente, $id_formacao){ 
            
            $data = date("Y-m-d");
            $hora = date("H:m:s");
            
              $dadosModulo = array(
               "concluido" => "S",
               "fim_modulo" => $data
           );            
                   
            alterar("historico_modulos", $dadosModulo, "id_cliente = $id_cliente and id_modulo = $id_modulo and id_formacao =$id_formacao" );
     }
	 
	function sinapse_curso_concluido($id_curso, $id_cliente){
		$total_aulas 	 = total("select id_aula from aulas where id_curso = $id_curso");
		$total_assistido = total("select id_aula from ag_aula_assistida where id_curso = $id_curso");
		if ($total_assistido >= $total_aulas)
			return true;
		else
			return false;
	}
function sinapse_semana_concluida($id_semana, $id_cliente,$id_treinamento){
		$total_aulas 	 = total("select a.id_aula from ag_curso_semana cs, aulas a where cs.id_curso = a.id_curso and id_treinamento = $id_treinamento and  id_semana = $id_semana");
		$total_assistido = total("select id_aula from ag_aula_assistida where id_treinamento = $id_treinamento and id_cliente = $id_cliente and id_semana = $id_semana");
		if ($total_assistido >= $total_aulas)
			return true;
		else
			return false;
	}	
