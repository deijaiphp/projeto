<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>CREA JR MARANHÃO</title>
<link href="css/estilo.css" rel="stylesheet" type="text/css">
<link href="css/estilo-m.css" rel="stylesheet" type="text/css">
<meta name="viewport" content="width=device-width, initial-scale=1">

<script src="//code.jquery.com/jquery-2.1.3.min.js"></script>
	<script>
			function abreFecha(sel) {
			$(sel).slideToggle();
			}
	</script>

		
</head>
<body>

<div class="base-topo">
		<div class="topo">
			<div class="caixa-topo">
				<div class="conteudo">
					<a href="index.php" class="logo"><img src="img/logo.png"></a>
					<form action="pesquisa.php" method="POST" name="">
						<input type="text" value="" name="" placeholder="PESQUISA">
						<input type="submit" value="" name="" class="but">
					</form>
					<ul>
						<li><a href="lst_video.php">VÍDEOS</a></li>
						<li><a href="frm_login.php">LOGIN</a></li>
						<li><a href="frm_cadastro.php" class="usuario">CADASTRA-SE</a></li>
					</ul>
				</div>
			</div>
			<div class="topo-menu">
			<div id="menu">
				<a href="javascript:abreFecha('#mostrarmenu')" class="mobmenu">MENU</a>
				<div class="conteudo" id="mostrarmenu">				
					<ul>
						<li><a href="index.php">home</a> </li>    
						<li><a href="categoria.php">php</a> </li>    
						<li><a href="categoria.php">java</a> </li>    
						<li><a href="categoria.php">html</a> </li>    
						<li><a href="categoria.php">css</a> </li>    
						<li><a href="categoria.php">javascript</a> </li>    
						<li><a href="categoria.php">delphi</a> </li>    
						<li><a href="categoria.php">vb.net</a> </li>
						
						<!-- aqui mostra só no mobile -->
						<div class="mostra">
							<li><a href="lst_video.php">VÍDEOS</a></li>
							<li><a href="frm_login.php">LOGIN</a></li>
							<li><a href="frm_cadastro.php">CADASTRAR</a></li>
							<li><a href="">Sair</a></li>
								
						</div>	
					</ul>
				</div>
			</div>
			</div>
		</div>
	</div>
	
				
		<div class="limpar"></div>
	<div class="base-banner">
		<div class="banner">
			<div class="conteudo">
				<h1>Inscreva-se e receba conteúdo gratuito toda semana.</h1>
				<form action="" method="">
					<label>
						<span>Nome</span>
						<input type="text" value="" name="" placeholder="Digite seu nome aqui">
					</label>
					<label>
						<span>Email</span>
						<input type="text" value="" name="" placeholder="Digite seu email aqui">
					</label>
					<label>
						<input type="submit" value="Quero receber novidades" name="" class="but">
					</label>
					<small>Não enviamos span todos os nossos conteúdos são de autorias próprias ou de fontes segura</small>
				</form>
			</div>
			<h2>AQUI VOCÊ ENCONTRA O MELHOR ACERVO DE PROGRAMAÇÃO</h2>
		</div>
	</div>