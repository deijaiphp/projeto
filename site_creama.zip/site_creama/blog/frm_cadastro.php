<?php include "cabecalho.php"; ?>
	
	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">
				<h1>cadastre-se aqui</h1>
				<div class="post-geral formulario">
					<form action="" method="" name="">
						<label>
							<span>Nome</span>
								<input name="" type="text" placeholder="Digite seu nome">							
						</label>
						<label>
							<span>Email</span>
								<input name="" type="text" placeholder="Digite seu emai">							
						</label>
						<label class="esquerdo">
							<span>Senha</span>
								<input name="" type="text"  placeholder="Digite uma senha">							
						</label>
						<label class="direito">
							<span>Confirma Senha</span>
								<input name="" type="text"  placeholder="Confirme sua senha">							
						</label>
						<label><input name="" type="submit" value="Cadastrar" class="btn"></label>
					</form>
				</div>			
			</div>
			
		
		
		<!-- sidebar -->	
		<?php include "sidebar.php"; ?>
	
	<!-- rodape -->	
	<?php include "rodape.php"; ?>