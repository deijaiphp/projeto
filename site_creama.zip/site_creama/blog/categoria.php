<?php include "cabecalho.php"; ?>

	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">			
			
				<div class="post-geral">	<h2>categoria <span>php</span></h2>
					<div class="categoria">
					<article>
						<a href="post.php"><img src="upload/img02.jpg">
						<div class="texto">
							<h3>Titulo do post aqui</h3>
						</a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>					
							<p><a href="post.php" class="btn">Ver post</a></p>
						</div>
					</article>	
					
					<article>
						<a href="post.php"><img src="upload/img02.jpg">
						<div class="texto">
							<h3>Titulo do post aqui</h3>
						</a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>					
							<p><a href="post.php" class="btn">Ver post</a></p>
						</div>
					</article>
					
					
					<article>
						<a href="post.php"><img src="upload/img02.jpg">
						<div class="texto">
							<h3>Titulo do post aqui</h3>
						</a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>					
							<p><a href="post.php" class="btn">Ver post</a></p>
						</div>
					</article>
					
					
					<article>
						<a href="post.php"><img src="upload/img02.jpg">
						<div class="texto">
							<h3>Titulo do post aqui</h3>
						</a>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh elit euismod tincidunt ut consectetuer elit nibh Lorem ipsum dolor sit amet, consectetuer</p>					
							<p><a href="post.php" class="btn">Ver post</a></p>
						</div>
					</article>
					
				
					<ul class="base-paginacao">
						<li><a href="" class="anterior">Anterior</a></li>
						<li><a href="">1</a></li>
						<li><a href="">2</a></li>
						<li><a href="">3</a></li>
						<li><a href="">4</a></li>
						<li><a href="">5</a></li>
						<li><a href="">6</a></li>
						<li><a href="">7</a></li>
						<li><a href="">8</a></li>
						<li><a href="">9</a></li>
						<li><a href="">...</a></li>
						<li><a href="" class="proximo">Próximo</a></li>
					</ul>
					
				</div>			
			</div>			
		</div>
			
		<!-- sidebar -->	
	<?php include "sidebar.php"; ?>
	<!-- rodape -->	
	
	<?php include "rodape.php"; ?>