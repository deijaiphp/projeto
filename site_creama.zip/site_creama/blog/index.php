<?php


include "cabecalho.php";


$url = (isset($_GET['url'])) ? $_GET['url'] : "";
$explode = explode("/", $url);

$paginas = array("home", "categoria", "post", "pesquisa", "frm_cadastro", "frm_login", "lst_video", "vervideo");

  if (isset($explode[0]) && $explode[0] == "")
   {
  	 include "home.php";
   }
  elseif ($explode[0] != "") 
  {
  	if (isset($explode[0]) && in_array($explode, $paginas)) 
  	{
  		include_once $explode[0].".php";
  	}
  	else
  	{
  		include_once "home.php";
  	}
  	
  }


var_dump($explode);



include "sidebar.php";


include "rodape.php";





 ?>
	
	
			
	