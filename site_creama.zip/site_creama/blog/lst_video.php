<?php include "cabecalho.php"; ?>
	
	<div class="conteudo">
		<div class="base-home">	
			<div class="lado-esq">
				<h1>POSTS EM VIDEO</h1>
				<div class="post-geral">
				<div class="categoria">
					<div class="lst-video">
						<h2>CATEGORIA <i class="seta-dupla"></i> <span>PHP</span></h2>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img02.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
					</div>	
					
					<div class="limpar"></div>
					
					<div class="lst-video">
						<h2>CATEGORIA <i class="seta-dupla"></i> <span>JAVA</span></h2>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img03.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img03.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img03.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
							
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img04.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img04.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img04.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>		
							</article>
					</div>	
					
					<div class="limpar"></div>
						
					<div class="lst-video">
						<h2>CATEGORIA <i class="seta-dupla"></i> <span>HTML</span></h2>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img05.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>		
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img05.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>		
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img05.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
							
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img06.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>		
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img06.jpg">
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>		
							</article>
							<article>
								<a href="vervideo.html"><i class="play"></i><img src="upload/img06.jpg">	
								<h3>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</h3></a>	
							</article>
					</div>	
													
				</div>			
				</div>			
			</div>
			
		
		
		<!-- sidebar -->	
		<?php include "sidebar.php"; ?>
	
	<!-- rodape -->
	<?php include "rodape.php"; ?>