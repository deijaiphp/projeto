<!-- sidebar -->	
		<div class="lado-dir">
				<h1>POST MAIS VISTO</h1>
				<figure>
					<a href="post.html"><img src="upload/img01.jpg">
					<figcaption>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</figcaption></a>
				</figure>
				
				<figure>
					<a href="post.html"><img src="upload/img02.jpg">
					<figcaption>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</figcaption></a>
				</figure>
				
				<figure>
					<a href="post.html"><img src="upload/img03.jpg">
					<figcaption>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</figcaption></a>
				</figure>
				
				<figure>
					<a href="post.html"><img src="upload/img04.jpg">
					<figcaption>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</figcaption></a>
				</figure>
				
				<figure>
					<a href=""><img src="upload/img05.jpg">
					<figcaption>Lorem ipsum dolor sit amet, consectetuer sit adipiscing elit</figcaption></a>
				</figure>
				<div class="limpar"></div>
				
				<h1>Newsletter</h1>
				<div class="news">
					<form action="" method="">
						<input type="text" name="" placeholder="Digite seu email...">
						<input type="radio" name="newletter" id="sim" value="radio"><label for="sim">Quero receber novidades</label><br/>
						<input type="radio" name="newletter" id="nao" value="radio"><label for="nao">Não quero receber novidades</label>
						<input type="submit" name="" value="enviar newsletter" class="btn">
					</form>
				</div>	
				
				<div class="limpar"></div>
				<h1>PUBLICIDADE</h1>
				<div class="public">
					<img src="img/public01.png">
					<img src="img/public02.png">
					<img src="img/public03.png">
				</div>
			</div>
			
		</div>	
	</div>