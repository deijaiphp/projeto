-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 19-Out-2016 às 00:31
-- Versão do servidor: 5.7.14
-- PHP Version: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `site_creama`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `categoria_id` int(11) NOT NULL,
  `categoria_titulo` varchar(200) NOT NULL,
  `categoria_slug` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`categoria_id`, `categoria_titulo`, `categoria_slug`) VALUES
(46, 'Oi Plano', 'oi-plano'),
(34, 'Categria Esportes vivo', 'categria-esportes-vivo'),
(35, 'Categria Esportes', 'categria-esportes'),
(38, 'Categria Esportes', 'categria-esportes'),
(22, 'Categria Esportes', 'categria-esportes'),
(23, 'Arte Produtos', 'arte-produtos'),
(24, 'Categria Esportes', 'categria-esportes'),
(40, 'Vivo Zuum branco', 'vivo-zuum-branco'),
(45, 'Claro Palno', 'claro-palno'),
(44, 'Oi Plano', 'oi-plano'),
(47, 'Oi Plano', 'oi-plano'),
(48, 'Oi Plano', 'oi-plano'),
(49, 'Oi Plano', 'oi-plano'),
(50, 'Oi Plano', 'oi-plano'),
(51, 'Oi Plano', 'oi-plano'),
(52, 'Oi Plano - Vivo', 'oi-plano-vivo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `post`
--

CREATE TABLE `post` (
  `post_id` int(11) NOT NULL,
  `post_id_categoria` int(11) NOT NULL,
  `post_titlulo` varchar(200) NOT NULL,
  `post_slug` varchar(200) NOT NULL,
  `post_imagem` varchar(200) NOT NULL,
  `post_descricao` text NOT NULL,
  `post_views` int(11) NOT NULL,
  `post_data` date NOT NULL,
  `post_video` varchar(200) NOT NULL,
  `post_ativo` char(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `usuario_id` int(3) NOT NULL,
  `usuario_nome` varchar(100) NOT NULL,
  `usuario_email` varchar(150) NOT NULL,
  `usuario_senha` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`usuario_id`, `usuario_nome`, `usuario_email`, `usuario_senha`) VALUES
(1, 'Deijai Miranda', 'djairn18@gmail.com', 'branco2013'),
(2, 'Edhymilkson Moises', 'moises@gmail.com', 'moises2013');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`categoria_id`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`post_id`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`usuario_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `categoria_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `post_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `usuario_id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
